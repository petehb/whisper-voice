package com.petehb.gabsvoice;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.AudioDeviceCallback;
import android.media.AudioDeviceInfo;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.ByteArrayOutputStream;
import java.util.Locale;

/**
 * Gabs' Voice: a full-screen shell around the web app that records with Android's own
 * recorder, so it can pick the USB lav mic (Chrome only offers "call" microphones).
 * The web page talks to this through window.GabsNative.
 */
public class MainActivity extends Activity {
    static final String HOME = "https://petehb.github.io/whisper-voice/";
    static final String HOST = "petehb.github.io";
    static final int REQ_MIC = 7;
    static final int MAX_SECONDS = 70;

    WebView web;
    AudioManager am;
    final Handler ui = new Handler(Looper.getMainLooper());

    // Recording state (touched from the JS bridge thread and the capture thread).
    final Object lock = new Object();
    volatile boolean running = false;
    volatile float gain = 2f;
    AudioRecord rec;
    Thread worker;
    ByteArrayOutputStream pcm;
    boolean keep;
    int rate;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        am = (AudioManager) getSystemService(AUDIO_SERVICE);

        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setCacheMode(WebSettings.LOAD_NO_CACHE); // always pick up the latest web app
        web.addJavascriptInterface(new Bridge(), "GabsNative");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (HOST.equals(u.getHost())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) {}
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(PermissionRequest request) {
                // The page records through GabsNative, so web mic access isn't needed.
                request.deny();
            }
        });
        setContentView(web);
        hideBars();
        web.loadUrl(HOME);

        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
        }
        am.registerAudioDeviceCallback(new AudioDeviceCallback() {
            @Override public void onAudioDevicesAdded(AudioDeviceInfo[] d) { js("window.__gvDevices&&__gvDevices()"); }
            @Override public void onAudioDevicesRemoved(AudioDeviceInfo[] d) { js("window.__gvDevices&&__gvDevices()"); }
        }, ui);
    }

    void hideBars() {
        web.setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideBars();
    }

    @Override
    public void onBackPressed() {
        // Back goes to the app's start screen rather than closing the app.
        js("window.__gvBack&&__gvBack()");
    }

    @Override
    protected void onDestroy() {
        stopCapture(false);
        super.onDestroy();
    }

    void js(String code) {
        ui.post(() -> { if (web != null) web.evaluateJavascript(code, null); });
    }

    static String esc(String s) {
        if (s == null) return "";
        StringBuilder b = new StringBuilder();
        for (char c : s.toCharArray()) {
            if (c == '"' || c == '\\') b.append('\\').append(c);
            else if (c < 0x20) b.append(' ');
            else b.append(c);
        }
        return b.toString();
    }

    static String kind(int type) {
        switch (type) {
            case AudioDeviceInfo.TYPE_BUILTIN_MIC: return "Tablet mic";
            case AudioDeviceInfo.TYPE_USB_DEVICE: return "USB mic";
            case AudioDeviceInfo.TYPE_USB_HEADSET: return "USB headset";
            case AudioDeviceInfo.TYPE_USB_ACCESSORY: return "USB accessory";
            case AudioDeviceInfo.TYPE_WIRED_HEADSET: return "Wired headset";
            case AudioDeviceInfo.TYPE_BLUETOOTH_SCO: return "Bluetooth";
            case AudioDeviceInfo.TYPE_TELEPHONY: return "Telephony";
            default: return "Input " + type;
        }
    }

    static boolean isUsb(int type) {
        return type == AudioDeviceInfo.TYPE_USB_DEVICE || type == AudioDeviceInfo.TYPE_USB_HEADSET
                || type == AudioDeviceInfo.TYPE_USB_ACCESSORY;
    }

    static String name(AudioDeviceInfo d) {
        String p = d.getProductName() == null ? "" : d.getProductName().toString().trim();
        String k = kind(d.getType());
        return p.isEmpty() || p.equalsIgnoreCase(k) ? k : k + ": " + p;
    }

    AudioDeviceInfo findDevice(String id) {
        AudioDeviceInfo[] all = am.getDevices(AudioManager.GET_DEVICES_INPUTS);
        if (id == null || id.equals("auto") || id.isEmpty()) {
            for (AudioDeviceInfo d : all) if (isUsb(d.getType())) return d;
            return null; // let Android choose (built-in mic)
        }
        for (AudioDeviceInfo d : all) if (String.valueOf(d.getId()).equals(id)) return d;
        for (AudioDeviceInfo d : all) if (isUsb(d.getType())) return d;
        return null;
    }

    AudioRecord makeRecorder(int r) {
        int min = AudioRecord.getMinBufferSize(r, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
        if (min <= 0) return null;
        try {
            AudioRecord a = new AudioRecord(MediaRecorder.AudioSource.MIC, r,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, Math.max(min, r / 5) * 2);
            if (a.getState() == AudioRecord.STATE_INITIALIZED) return a;
            a.release();
        } catch (Exception ignored) {}
        return null;
    }

    String startCapture(String id, double g, boolean keepAudio) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ui.post(() -> requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC));
            return "{\"ok\":false,\"error\":\"permission\"}";
        }
        stopCapture(false);
        synchronized (lock) {
            AudioDeviceInfo want = findDevice(id);
            int[] rates = {16000, 48000, 44100};
            AudioRecord a = null;
            for (int r : rates) { a = makeRecorder(r); if (a != null) { rate = r; break; } }
            if (a == null) return "{\"ok\":false,\"error\":\"Could not open the microphone\"}";
            if (want != null) a.setPreferredDevice(want);
            gain = (float) g;
            keep = keepAudio;
            pcm = new ByteArrayOutputStream();
            rec = a;
            try { a.startRecording(); } catch (Exception e) {
                a.release(); rec = null;
                return "{\"ok\":false,\"error\":\"" + esc(e.getMessage()) + "\"}";
            }
            running = true;
            final AudioRecord ar = a;
            final int r = rate;
            worker = new Thread(() -> loop(ar, r), "gabs-capture");
            worker.start();
        }
        // Give Android a moment to settle the route, then report what we really got.
        try { Thread.sleep(250); } catch (InterruptedException ignored) {}
        AudioDeviceInfo routed = rec != null ? rec.getRoutedDevice() : null;
        String label = routed != null ? name(routed) : "Default microphone";
        boolean usb = routed != null && isUsb(routed.getType());
        return "{\"ok\":true,\"label\":\"" + esc(label) + "\",\"usb\":" + usb + ",\"rate\":" + rate
                + ",\"id\":\"" + (routed != null ? routed.getId() : "") + "\"}";
    }

    void loop(AudioRecord a, int r) {
        short[] buf = new short[r / 20]; // 50 ms
        byte[] out = new byte[buf.length * 2];
        long limit = (long) r * MAX_SECONDS;
        long total = 0;
        while (running) {
            int n = a.read(buf, 0, buf.length);
            if (n <= 0) continue;
            float g = gain;
            double sum = 0;
            for (int i = 0; i < n; i++) {
                int v = Math.round(buf[i] * g);
                if (v > 32767) v = 32767; else if (v < -32768) v = -32768;
                sum += (double) v * v;
                out[i * 2] = (byte) (v & 0xff);
                out[i * 2 + 1] = (byte) ((v >> 8) & 0xff);
            }
            if (keep && total < limit) { synchronized (lock) { pcm.write(out, 0, n * 2); } total += n; }
            double level = Math.min(1.0, Math.sqrt(sum / n) / 32768.0 * 10.0);
            js(String.format(Locale.US, "window.__gvLevel&&__gvLevel(%.3f)", level));
        }
    }

    String stopCapture(boolean want) {
        Thread w;
        AudioRecord a;
        synchronized (lock) { running = false; w = worker; a = rec; worker = null; rec = null; }
        if (w != null) { try { w.join(1500); } catch (InterruptedException ignored) {} }
        if (a != null) { try { a.stop(); } catch (Exception ignored) {} a.release(); }
        if (!want || pcm == null) return "";
        byte[] data;
        synchronized (lock) { data = pcm.toByteArray(); pcm = null; }
        return Base64.encodeToString(wav(data, rate), Base64.NO_WRAP);
    }

    static byte[] wav(byte[] pcm, int rate) {
        int len = pcm.length;
        byte[] h = new byte[44];
        put(h, 0, "RIFF"); le32(h, 4, 36 + len); put(h, 8, "WAVE"); put(h, 12, "fmt ");
        le32(h, 16, 16); le16(h, 20, 1); le16(h, 22, 1); le32(h, 24, rate); le32(h, 28, rate * 2);
        le16(h, 32, 2); le16(h, 34, 16); put(h, 36, "data"); le32(h, 40, len);
        byte[] all = new byte[44 + len];
        System.arraycopy(h, 0, all, 0, 44);
        System.arraycopy(pcm, 0, all, 44, len);
        return all;
    }
    static void put(byte[] b, int o, String s) { for (int i = 0; i < 4; i++) b[o + i] = (byte) s.charAt(i); }
    static void le32(byte[] b, int o, int v) { b[o] = (byte) v; b[o + 1] = (byte) (v >> 8); b[o + 2] = (byte) (v >> 16); b[o + 3] = (byte) (v >> 24); }
    static void le16(byte[] b, int o, int v) { b[o] = (byte) v; b[o + 1] = (byte) (v >> 8); }

    /** Methods the web page can call as window.GabsNative.x(...). They run off the UI thread. */
    class Bridge {
        @JavascriptInterface
        public String listInputs() {
            StringBuilder b = new StringBuilder("[");
            AudioDeviceInfo[] all = am.getDevices(AudioManager.GET_DEVICES_INPUTS);
            boolean first = true;
            for (AudioDeviceInfo d : all) {
                if (d.getType() == AudioDeviceInfo.TYPE_TELEPHONY || d.getType() == AudioDeviceInfo.TYPE_REMOTE_SUBMIX) continue;
                if (!first) b.append(',');
                first = false;
                b.append("{\"id\":\"").append(d.getId()).append("\",\"name\":\"").append(esc(name(d)))
                        .append("\",\"type\":").append(d.getType()).append(",\"usb\":").append(isUsb(d.getType())).append('}');
            }
            return b.append(']').toString();
        }

        @JavascriptInterface
        public String start(String id, double gain, boolean keepAudio) { return startCapture(id, gain, keepAudio); }

        @JavascriptInterface
        public String stop(boolean want) { return stopCapture(want); }

        @JavascriptInterface
        public void setGain(double g) { gain = (float) g; }

        @JavascriptInterface
        public String version() {
            try { return getPackageManager().getPackageInfo(getPackageName(), 0).versionName; }
            catch (Exception e) { return "?"; }
        }
    }
}
